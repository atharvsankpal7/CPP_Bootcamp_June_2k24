#include <iostream>
using namespace std;
int main()
{
    int a;
    cout << "Enter the value of a --> ";
    cin >> a;
    if (a > 10)
    {
        cout << "Harsh";
    }
    else if (a < 10)
    {
        cout << "Prathamesh";
    }
    else
    {
        cout << "Gourav";
    }
}