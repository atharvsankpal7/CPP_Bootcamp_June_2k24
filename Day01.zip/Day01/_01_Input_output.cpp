#include <iostream>
using namespace std;
int main(){
    // output  
    cout << "Hello World\n";
    cout << "Hello World\n";

    // input
    int a;
    cout << "Enter the value of a --> ";
    cin >> a;
    cout << "the value of given variable is "<< endl << a << endl;
    cout << "hello program has been terminated";
    return 0;
}
